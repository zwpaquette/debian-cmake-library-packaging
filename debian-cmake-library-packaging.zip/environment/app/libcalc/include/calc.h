#ifndef CALC_H
#define CALC_H

/**
 * Add two integers
 */
int add(int a, int b);

/**
 * Multiply two integers
 */
int multiply(int a, int b);

#endif /* CALC_H */
